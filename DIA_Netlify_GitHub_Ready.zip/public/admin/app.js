const $=s=>document.querySelector(s), api='/api/';
let page=1,total=0,search='',filter='',timer;
function showLogin(){ $('#login').hidden=false;$('#dashboard').hidden=true }
function showDashboard(){ $('#login').hidden=true;$('#dashboard').hidden=false }
function message(text){const el=$('#toast');el.textContent=text;clearTimeout(timer);timer=setTimeout(()=>el.textContent='',4200)}
async function call(path,opts={}){
 const r=await fetch(api+path,{credentials:'same-origin',cache:'no-store',...opts});
 let v;try{v=await r.json()}catch{v={message:'Unexpected server response'}}
 if(!r.ok)throw Object.assign(new Error(v.message||'Request failed'),{status:r.status});return v;
}
function h(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function dates(s){if(!s)return '—';const d=new Date(s);return Number.isNaN(+d)?'—':d.toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'})}
async function checkSession(){try{const s=await call('session');$('#user-display').textContent=s.username;showDashboard();await load()}catch{showLogin()}}
async function load(){
 try{
  const res=await call('leads?'+new URLSearchParams({page,status:filter,search}));total=res.total;
  const counts=Object.fromEntries(res.summary.map(r=>[r.status,Number(r.count)]));
  $('#total').textContent=Object.values(counts).reduce((a,b)=>a+b,0);$('#new').textContent=counts.New||0;$('#interested').textContent=counts.Interested||0;$('#enrolled').textContent=counts.Enrolled||0;
  $('#lead-rows').innerHTML=res.rows.length?res.rows.map(r=>`<tr><td><span class="student">${h(r.full_name)}</span><a class="phone" href="tel:${h(r.phone)}">${h(r.phone)}</a></td><td><span class="pill">${h(r.language)}</span></td><td>${h(r.learning_mode)}<span class="detail">${h((r.centres||[]).join(', '))}</span></td><td>${h(r.education)}<span class="detail">${h(r.experience)}</span></td><td>${dates(r.created_at)}</td><td><select class="status-select" aria-label="Status for ${h(r.full_name)}" data-id="${h(r.id)}">${['New','Contacted','Interested','Enrolled','Closed'].map(x=>`<option ${x===r.status?'selected':''}>${x}</option>`).join('')}</select></td></tr>`).join(''):'<tr><td colspan="6">No enquiries match your filters yet.</td></tr>';
  $('#page-info').textContent=`${total?Math.min((page-1)*50+1,total):0}–${Math.min(page*50,total)} of ${total} enquiries`;
  $('#prev').disabled=page===1;$('#next').disabled=page*50>=total;
 }catch(e){if(e.status===401){showLogin();return}$('#lead-rows').innerHTML='<tr><td colspan="6">Unable to load enquiries. Check Netlify Function logs and database settings.</td></tr>';message(e.message)}
}
$('#login-form').addEventListener('submit',async ev=>{
 ev.preventDefault();$('#login-error').textContent='';const btn=$('#signin');btn.disabled=true;btn.textContent='Signing in…';
 try{const r=await call('login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({username:$('#username').value.trim(),password:$('#password').value})});$('#password').value='';$('#user-display').textContent=r.username;showDashboard();await load()}catch(e){$('#login-error').textContent=e.message}finally{btn.disabled=false;btn.innerHTML='Sign in to dashboard <span>↗</span>'}
});
$('#logout').addEventListener('click',async()=>{try{await call('logout',{method:'POST'})}catch{}showLogin()});
$('#lead-rows').addEventListener('change',async e=>{const el=e.target.closest('[data-id]');if(!el)return;el.disabled=true;try{await call('leads',{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:el.dataset.id,status:el.value})});message('Lead status updated');await load()}catch(err){message(err.message);await load()}finally{el.disabled=false}});
$('#search').addEventListener('input',()=>{clearTimeout(timer);timer=setTimeout(()=>{search=$('#search').value.trim();page=1;load()},350)});
$('#status-filter').addEventListener('change',()=>{filter=$('#status-filter').value;page=1;load()});
$('#refresh').addEventListener('click',load);
$('#prev').addEventListener('click',()=>{if(page>1){page--;load()}});
$('#next').addEventListener('click',()=>{if(page*50<total){page++;load()}});
$('#export').addEventListener('click',async()=>{try{const r=await fetch(api+'export',{credentials:'same-origin',cache:'no-store'});if(!r.ok)throw new Error('Export unavailable');const blob=await r.blob();const u=URL.createObjectURL(blob);const a=document.createElement('a');a.href=u;a.download='dia-enquiries.csv';document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(u)}catch(e){message(e.message)}});
checkSession();
