import {json,fail,session} from '../../lib/shared.mjs';
export default async req=>{
 if(req.method!=='GET')return fail(405,'Method not allowed');
 const s=session(req);return s?json({ok:true,username:s.username}):fail(401,'Not signed in');
};
