# DIA Academy — Netlify Admissions & Enquiry Platform

GitHub-ready application that deploys to **Netlify** and connects to the **existing CockroachDB** (`defaultdb`) tables. No PHP/cPanel PostgreSQL driver required.

## What's included

- `/admin/` — private admin login and leads dashboard, search, status updates, CSV export
- `/enquire/` — redesigned student enquiry form (8 courses, original options)
- `/api/enquiry` — server-side lead submission
- `/api/login`, `/api/logout`, `/api/session`, `/api/leads`, `/api/export` — protected backend
- `deploy/cpanel-dia-academy-website.html` — optional replacement of your **existing cPanel form**, configured to send enquiries to `https://admin.diacourses.com/api/enquiry`. **Do not use before the subdomain is live.**

## DEPLOYMENT — NO COMMAND LINE REQUIRED

**1. GitHub**: Create a PRIVATE repository named `dia-admissions`. Extract the ZIP on your computer. Upload **the contents of the folder**, not the ZIP itself and not the outer folder. The root of the repository must show `package.json`, `netlify.toml`, `public/`, `netlify/`.

**2. Netlify**: Add new project → Import an existing project → GitHub → select `dia-admissions`. Set **base directory** empty, **build command** empty, **publish directory** `public`, **functions directory** `netlify/functions` (these are already defined in `netlify.toml`). Deploy.

**3. Netlify → Project configuration → Environment variables**: Add these on the Netlify UI, not in GitHub:

- `DATABASE_URL` = newly rotated CockroachDB PostgreSQL URL, including `?sslmode=verify-full`
- `SESSION_SECRET` = a fresh random 64-character hex value (generate using a trusted local password manager or `openssl rand -hex 32` on your own computer)
- `ALLOWED_FORM_ORIGINS` = `https://www.diacourses.com,https://diacourses.com` (optional, set if using cPanel form)
- `DB_SSL_CA_BASE64` = base64-encoded custom CA PEM **only if required** by your CockroachDB connection (optional)

**4. Redeploy** after saving environment variables. Netlify Functions read variables at runtime, and redeploy ensures new configuration is applied.

**5. Verify CockroachDB SQL Shell**: Your database must already contain `dia_admin_users`, `dia_enquiries`, `dia_request_limits`. If not, run the `migrations/001_init.sql` from your previous PHP package. The SQL file is NOT executed by Netlify.

**6. Admin account**: The DB table must contain the user `765765` with a proper **PHP bcrypt / Node bcryptjs compatible** hash in `password_hash`. Because you previously created it in SQL Shell, do NOT recreate or duplicate the user unless needed.

**7. Test**: `https://YOUR-SITE.netlify.app/admin/` login; `.../enquire/` submit one test lead; view the lead, change status, export CSV. Delete test leads using the SQL Shell if desired. Test only on a private/staging deployment.

**8. Subdomain**: In Netlify → Domain management → Add custom domain `admin.diacourses.com`. Netlify will display the target hostname, e.g. `your-project.netlify.app`. In the authoritative DNS provider (often cPanel Zone Editor, but only if that handles your DNS), create **CNAME `admin` → your-project.netlify.app**. Do NOT change the records for the root or `www` website. Wait for DNS and automatic HTTPS provisioning.

**9. Existing form integration**: To preserve the existing form at `diacourses.com/dia-academy-website`, after the subdomain and SSL work upload `deploy/cpanel-dia-academy-website.html` to cPanel as `public_html/dia-academy-website.html` (back up the original). Its cross-origin API submission needs `ALLOWED_FORM_ORIGINS` above. Alternatively redirect main website course CTAs to `https://admin.diacourses.com/enquire/?course=Japanese` etc. Do not use both live forms until tested.

## SECURITY

- **Do not commit any passwords or real `.env` files to GitHub.** `.gitignore` excludes them; the example contains placeholders only.
- DB connection stays **server-side** in Netlify Functions. The browser never sees the database password.
- Admin login uses bcrypt check against the existing PHP-compatible hash; a signed, secure, HttpOnly, SameSite=Lax session cookie valid for 12 hours; CSRF origin checks on admin mutations.
- Enquiry submission checks allowed browser origins, has field validation, honeypot and database-backed IP throttling. Origin checks and rate limits reduce unwanted submissions but do not eliminate automated spam. Consider CAPTCHA and a privacy/retention policy before launch.
- **Admin UI and API must be tested before accepting real student data.** Do not rely only on a successful Netlify build to confirm database connectivity.
- Rotate the **previously disclosed** database and admin credentials; if compromised, revoke old ones.
- All personal data remains in CockroachDB. Verify consent, access control, data retention, and legal privacy obligations before production.
- CSV can contain personal information; handle it carefully.

## TROUBLESHOOTING

- Login says service unavailable → Netlify → Logs → Functions → `login` (look for `DIA login server error:`), verify `DATABASE_URL`, TLS and network access.
- Incorrect credentials → SQL Shell `SELECT username FROM dia_admin_users;` then verify password hash compatibility.
- Missing table → run `SHOW TABLES;` in `defaultdb` and apply previous migration.
- Enquiry does not save → check Netlify Function `enquiry` logs, allowed origin and database permissions.
- `404 /api/login` → make sure `netlify.toml` is at GitHub repo root and redeploy.
- CORS error from cPanel → add both `https://www.diacourses.com` and `https://diacourses.com` to `ALLOWED_FORM_ORIGINS` and redeploy.
- SSL failed → do not bypass TLS verification. Confirm CockroachDB hostname and if needed configure `DB_SSL_CA_BASE64` with the correct CA cert.

**This ZIP is code prepared for deployment; no live Netlify or CockroachDB connection was executed by its creator.**
