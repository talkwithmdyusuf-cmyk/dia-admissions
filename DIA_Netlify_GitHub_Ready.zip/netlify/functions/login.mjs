import {database,json,fail,method,sign,sessionCookie,passwordMatches,sanitizeText,ipHash} from '../../lib/shared.mjs';
export default async(req)=>{
 if(method(req,['POST']))return fail(405,'Method not allowed');
 if(req.headers.get('content-type')?.split(';')[0]!=='application/json')return fail(415,'Send JSON');
 if(!req.headers.get('origin')||new URL(req.headers.get('origin')).host!==new URL(req.url).host)return fail(403,'Invalid origin');
 try{
  const body=await req.json();
  const username=sanitizeText(body.username,40),password=String(body.password||'');
  if(!username||password.length<1||password.length>256)return fail(400,'Enter a valid user ID and password');
  // Simple DB-backed limit: five attempts per 15 minutes per IP.
  const key='login:'+ipHash(req);
  const limit=await database().query(`INSERT INTO dia_request_limits (key_hash,window_start,attempts) VALUES ($1,now(),1)
    ON CONFLICT (key_hash) DO UPDATE SET attempts=CASE WHEN dia_request_limits.window_start < now()-INTERVAL '15 minutes' THEN 1 ELSE dia_request_limits.attempts+1 END,
    window_start=CASE WHEN dia_request_limits.window_start < now()-INTERVAL '15 minutes' THEN now() ELSE dia_request_limits.window_start END RETURNING attempts`,[key]);
  if(Number(limit.rows[0].attempts)>5)return fail(429,'Too many attempts. Try again in 15 minutes.');
  const user=await database().query('SELECT id,username,password_hash FROM dia_admin_users WHERE username=$1 LIMIT 1',[username]);
  if(!user.rows.length||!await passwordMatches(password,user.rows[0].password_hash))return fail(401,'Incorrect user ID or password');
  await database().query('UPDATE dia_admin_users SET last_login_at=now() WHERE id=$1',[user.rows[0].id]);
  const token=sign({uid:user.rows[0].id,username:user.rows[0].username,exp:Date.now()+12*3600*1000});
  return json({ok:true,username},200,{'Set-Cookie':sessionCookie(token)});
 }catch(err){console.error('DIA login server error:',err.code||err.message);return fail(503,'Login service temporarily unavailable. Check Netlify function logs.');}
};
