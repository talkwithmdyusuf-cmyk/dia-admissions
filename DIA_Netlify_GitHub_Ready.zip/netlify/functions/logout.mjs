import {json,fail,sameOrigin,sessionCookie} from '../../lib/shared.mjs';
export default async req=>req.method!=='POST'?fail(405,'Method not allowed'):!sameOrigin(req)?fail(403,'Invalid origin'):json({ok:true},200,{'Set-Cookie':sessionCookie('',0)});
