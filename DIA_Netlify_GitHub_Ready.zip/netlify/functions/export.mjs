import {database,fail,session} from '../../lib/shared.mjs';
const escapeCell=v=>{let s=Array.isArray(v)?v.join(' | '):String(v??'');if(/^[\s]*[=+@\-\t\r]/.test(s))s="'"+s;return '"'+s.replaceAll('"','""')+'"'};
export default async req=>{
 if(req.method!=='GET')return fail(405,'Method not allowed');if(!session(req))return fail(401,'Sign in required');
 try{
  const res=await database().query('SELECT id,full_name,phone,language,learning_mode,centres,education,experience,notes,status,source_page,created_at FROM dia_enquiries ORDER BY created_at DESC LIMIT 10000');
  const fields=['id','full_name','phone','language','learning_mode','centres','education','experience','notes','status','source_page','created_at'];
  const csv='\ufeff'+fields.map(escapeCell).join(',')+'\r\n'+res.rows.map(row=>fields.map(f=>escapeCell(row[f])).join(',')).join('\r\n');
  return new Response(csv,{headers:{'Content-Type':'text/csv; charset=utf-8','Content-Disposition':'attachment; filename="dia-enquiries.csv"','Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff'}});
 }catch(e){console.error('DIA export error:',e.code||e.message);return fail(503,'Export unavailable');}
};
