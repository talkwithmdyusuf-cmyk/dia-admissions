-- CockroachDB-compatible schema (run once using psql or Cockroach SQL client).
CREATE TABLE IF NOT EXISTS dia_admin_users (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 username STRING NOT NULL UNIQUE,
 password_hash STRING NOT NULL,
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 last_login_at TIMESTAMPTZ
);
CREATE TABLE IF NOT EXISTS dia_enquiries (
 id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
 full_name STRING NOT NULL,
 phone STRING NOT NULL,
 language STRING NOT NULL,
 learning_mode STRING NOT NULL,
 centres STRING[] NOT NULL DEFAULT ARRAY[]::STRING[],
 education STRING NOT NULL,
 experience STRING NOT NULL,
 notes STRING,
 source_page STRING NOT NULL DEFAULT '/dia-academy-website',
 status STRING NOT NULL DEFAULT 'New',
 consent_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
 CONSTRAINT valid_mode CHECK (learning_mode IN ('Online','Offline')),
 CONSTRAINT valid_status CHECK (status IN ('New','Contacted','Interested','Enrolled','Closed'))
);
CREATE INDEX IF NOT EXISTS dia_enquiries_recent_idx ON dia_enquiries (created_at DESC);
CREATE INDEX IF NOT EXISTS dia_enquiries_status_idx ON dia_enquiries (status, created_at DESC);
CREATE TABLE IF NOT EXISTS dia_request_limits (
 key_hash STRING PRIMARY KEY,
 window_start TIMESTAMPTZ NOT NULL DEFAULT now(),
 attempts INT8 NOT NULL DEFAULT 1
);
