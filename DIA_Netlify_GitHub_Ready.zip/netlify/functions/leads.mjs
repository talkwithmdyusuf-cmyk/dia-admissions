import {database,json,fail,session,sameOrigin,allowedStatus} from '../../lib/shared.mjs';
export default async req=>{
 const admin=session(req);if(!admin)return fail(401,'Please sign in');
 try{
  if(req.method==='GET'){
   const url=new URL(req.url);const status=url.searchParams.get('status')||'';
   const search=(url.searchParams.get('search')||'').trim().slice(0,80);
   const page=Math.min(10000,Math.max(1,Number(url.searchParams.get('page'))||1));
   if(status&&!allowedStatus.includes(status))return fail(400,'Invalid status');
   const filters=[];const params=[];
   if(status){params.push(status);filters.push(`status=$${params.length}`)}
   if(search){params.push('%'+search.replace(/[\\%_]/g,'\\$&')+'%');filters.push(`(full_name ILIKE $${params.length} OR phone ILIKE $${params.length} OR language ILIKE $${params.length})`)}
   const where=filters.length?' WHERE '+filters.join(' AND '):'';
   const count=await database().query('SELECT count(*)::int AS count FROM dia_enquiries'+where,params);
   const rows=await database().query(`SELECT id,full_name,phone,language,learning_mode,centres,education,experience,notes,status,source_page,created_at,updated_at FROM dia_enquiries${where} ORDER BY created_at DESC LIMIT 50 OFFSET $${params.length+1}`,[...params,(page-1)*50]);
   const summary=await database().query('SELECT status,count(*)::int AS count FROM dia_enquiries GROUP BY status');
   return json({ok:true,rows:rows.rows,total:Number(count.rows[0].count),page,summary:summary.rows});
  }
  if(req.method==='PATCH'){
   if(!sameOrigin(req))return fail(403,'Invalid origin');
   if(req.headers.get('content-type')?.split(';')[0]!=='application/json')return fail(415,'Send JSON');
   const b=await req.json();if(!/^[0-9a-f-]{36}$/i.test(b.id||'')||!allowedStatus.includes(b.status))return fail(400,'Invalid enquiry or status');
   const result=await database().query('UPDATE dia_enquiries SET status=$1,updated_at=now() WHERE id=$2 RETURNING id,status',[b.status,b.id]);
   return result.rowCount?json({ok:true,row:result.rows[0]}):fail(404,'Enquiry not found');
  }
  return fail(405,'Method not allowed');
 }catch(err){console.error('DIA leads error:',err.code||err.message);return fail(503,'Database temporarily unavailable');}
};
