import {database,json,fail,cors,isAllowedPublicOrigin,ipHash,allowedCourses,allowedEducation,allowedExperience,allowedCentres,sanitizeText} from '../../lib/shared.mjs';
export default async req=>{
 const origin=req.headers.get('origin');const headers=cors(origin,req);
 if(req.method==='OPTIONS')return new Response(null,{status:isAllowedPublicOrigin(origin,req)?204:403,headers});
 if(req.method!=='POST')return fail(405,'Method not allowed');
 if(!isAllowedPublicOrigin(origin,req))return json({ok:false,message:'Origin not allowed'},403,headers);
 if(req.headers.get('content-type')?.split(';')[0]!=='application/json')return json({ok:false,message:'Send JSON'},415,headers);
 try{
  const raw=await req.text();if(raw.length>12000)return json({ok:false,message:'Request too large'},413,headers);
  const b=JSON.parse(raw),name=sanitizeText(b.full_name),phone=sanitizeText(b.phone,15),language=sanitizeText(b.language,40),mode=sanitizeText(b.learning_mode,20),education=sanitizeText(b.education,60),experience=sanitizeText(b.experience,30);
  const centres=Array.isArray(b.centres)?b.centres.filter(v=>typeof v==='string').slice(0,8):[];
  if(b.website)return json({ok:true,reference:'Received'},200,headers); // honeypot - no storage
  if(!b.consent||name.length<2||!/^[6-9][0-9]{9}$/.test(phone)||!allowedCourses.includes(language)||!['Online','Offline'].includes(mode)||!allowedEducation.includes(education)||!allowedExperience.includes(experience)||centres.some(c=>!allowedCentres.includes(c))||(mode==='Offline'&&!centres.length))return json({ok:false,message:'Please complete all required fields accurately.'},400,headers);
  const key='enquiry:'+ipHash(req);
  const limit=await database().query(`INSERT INTO dia_request_limits (key_hash,window_start,attempts) VALUES ($1,now(),1)
   ON CONFLICT (key_hash) DO UPDATE SET attempts=CASE WHEN dia_request_limits.window_start < now()-INTERVAL '1 hour' THEN 1 ELSE dia_request_limits.attempts+1 END,
   window_start=CASE WHEN dia_request_limits.window_start < now()-INTERVAL '1 hour' THEN now() ELSE dia_request_limits.window_start END RETURNING attempts`,[key]);
  if(Number(limit.rows[0].attempts)>8)return json({ok:false,message:'Too many enquiries. Please contact DIA Academy by phone.'},429,headers);
  const result=await database().query(`INSERT INTO dia_enquiries (full_name,phone,language,learning_mode,centres,education,experience,notes,source_page,status,consent_at)
   VALUES ($1,$2,$3,$4,$5::STRING[],$6,$7,$8,$9,'New',now()) RETURNING id`,[name,phone,language,mode,mode==='Online'?[]:centres,education,experience,sanitizeText(b.notes,500),sanitizeText(b.source_page,140)||'/dia-academy-website']);
  return json({ok:true,reference:String(result.rows[0].id).slice(0,8)},201,headers);
 }catch(e){console.error('DIA submission error:',e.code||e.message);return json({ok:false,message:'We could not save your enquiry right now. Please call DIA Academy.'},503,headers)}
};
